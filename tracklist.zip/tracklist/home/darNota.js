// darNota.js
// funcao responsavel por guardar a nota que o usuario clicou

function darNota(nota) {
  notaEscolhida = nota;
  alert("Você selecionou " + nota + " estrelas!");
}
