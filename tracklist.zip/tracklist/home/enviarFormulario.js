// enviarFormulario.js
// funcao responsavel por enviar o formulario (de forma simulada)

function enviarFormulario() {
  // primeiro verifica se os campos estao certos
  var camposOk = validarFormulario();

  if (camposOk == false) {
    return; // se tiver erro, para aqui e nao envia
  }

  var nome = document.getElementById("nome").value;

  // aqui normalmente enviariamos os dados para um banco de dados,
  // mas como é só um exemplo, vamos simular o envio com um setTimeout

  document.getElementById("mensagemSucesso").innerText = "Enviando...";

  setTimeout(function () {
    document.getElementById("mensagemSucesso").innerText =
      "Mensagem enviada com sucesso, " + nome + "! Em breve responderemos.";

    // limpa o formulario depois de enviar
    document.getElementById("nome").value = "";
    document.getElementById("email").value = "";
    document.getElementById("mensagem").value = "";
  }, 1500);
}
