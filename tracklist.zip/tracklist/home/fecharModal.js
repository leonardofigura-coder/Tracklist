// fecharModal.js
// funcao responsavel por fechar a janela (modal) de avaliacao

function fecharModal() {
  document.getElementById("modal").style.display = "none";
}
