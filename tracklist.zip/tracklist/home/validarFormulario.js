// validarFormulario.js
// funcao responsavel por verificar se os campos do formulario estao certos

function validarFormulario() {
  var nome = document.getElementById("nome").value;
  var email = document.getElementById("email").value;
  var mensagem = document.getElementById("mensagem").value;

  var formularioValido = true; // comeca como true, e vira false se achar erro

  // limpa as mensagens de erro antes de validar de novo
  document.getElementById("erroNome").innerText = "";
  document.getElementById("erroEmail").innerText = "";
  document.getElementById("erroMensagem").innerText = "";

  // valida o nome (nao pode ser vazio)
  if (nome == "") {
    document.getElementById("erroNome").innerText = "Digite seu nome.";
    formularioValido = false;
  }

  // valida o email (precisa ter @ e um ponto depois do @)
  if (email == "") {
    document.getElementById("erroEmail").innerText = "Digite seu e-mail.";
    formularioValido = false;
  } else if (email.indexOf("@") == -1) {
    document.getElementById("erroEmail").innerText = "E-mail inválido.";
    formularioValido = false;
  }

  // valida a mensagem (nao pode ser vazia e precisa ter pelo menos 10 letras)
  if (mensagem == "") {
    document.getElementById("erroMensagem").innerText = "Digite uma mensagem.";
    formularioValido = false;
  } else if (mensagem.length < 10) {
    document.getElementById("erroMensagem").innerText = "Mensagem muito curta.";
    formularioValido = false;
  }

  return formularioValido;
}
