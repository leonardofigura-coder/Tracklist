// dados.js
// guarda a lista de albuns e as variaveis que vao sendo usadas pelo site

// lista de albuns (poderia vir de um banco de dados, mas aqui é fixo)
var albuns = [
  { imagem: "imagens/album1.png", titulo: "ICEMAN", artista: "Drake", nota: 4 },
  { imagem: "imagens/album2.png", titulo: "Aduto Ideal Vol.2", artista: "Ryu, The Runner", nota: 4 },
  { imagem: "imagens/album3.png", titulo: "Sobrevivendo no Inferno", artista: "Racionais MC's", nota: 3 },
  { imagem: "imagens/album4.png", titulo: "Talvez Você Precise de Mim", artista: "Veigh", nota: 5 },
  { imagem: "imagens/album5.png", titulo: "The Life of a Showgirl", artista: "Taylor Swift", nota: 3 },
  { imagem: "imagens/album6.png", titulo: "Poderoso Chatão", artista: "MC Lele JP", nota: 4 }
];

var albumSelecionado = 0; // guarda qual album foi clicado
var notaEscolhida = 0; // guarda a nota que o usuario escolheu no modal
