function cadastrarUsuario() {

  let nome = document.getElementById("cadNome").value;
  let usuario = document.getElementById("cadUsuario").value;
  let email = document.getElementById("cadEmail").value;

  if(nome === "" || usuario === "" || email === ""){
    alert("Preencha todos os campos obrigatórios!");
    return;
  }

  document.getElementById("mensagemCadastro").innerHTML =
    "Cadastro realizado com sucesso!";

}