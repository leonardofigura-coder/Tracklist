// abrirModal.js
// funcao responsavel por abrir a janela (modal) de avaliacao

function abrirModal(indice) {
  albumSelecionado = indice;
  notaEscolhida = 0;

  var album = albuns[indice];

  document.getElementById("modalImg").src = album.imagem;
  document.getElementById("modalTitulo").innerText = album.titulo;
  document.getElementById("modalArtista").innerText = album.artista;
  document.getElementById("modalResenha").value = "";

  document.getElementById("modal").style.display = "flex";
}
