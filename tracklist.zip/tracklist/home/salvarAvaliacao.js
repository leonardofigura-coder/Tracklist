// salvarAvaliacao.js
// funcao responsavel por salvar a avaliacao feita pelo usuario

function salvarAvaliacao() {
  if (notaEscolhida == 0) {
    alert("Escolha uma nota antes de salvar!");
    return;
  }

  var album = albuns[albumSelecionado];
  alert("Você avaliou " + album.titulo + " com " + notaEscolhida + " estrelas!");

  fecharModal();
}
