// montarCards.js
// funcao responsavel por criar os cards de album na tela

function montarCards() {
  var grade = document.getElementById("grade");

  for (var i = 0; i < albuns.length; i++) {
    var album = albuns[i];

    // cria as estrelinhas em texto (★★★★☆)
    var estrelasTexto = "";
    for (var j = 1; j <= 5; j++) {
      if (j <= album.nota) {
        estrelasTexto += "★";
      } else {
        estrelasTexto += "☆";
      }
    }

    // monta o html do card
    var html = "";
    html += "<div class='card-album' onclick='abrirModal(" + i + ")'>";
    html += "<img src='" + album.imagem + "' alt='" + album.titulo + "'>";
    html += "<h4>" + album.titulo + "</h4>";
    html += "<p>" + album.artista + "</p>";
    html += "<p class='estrelas'>" + estrelasTexto + "</p>";
    html += "</div>";

    grade.innerHTML += html;
  }
}
