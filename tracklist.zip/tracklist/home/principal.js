// principal.js
// arquivo principal, roda quando a pagina termina de carregar

window.onload = function () {
  montarCards();
};
